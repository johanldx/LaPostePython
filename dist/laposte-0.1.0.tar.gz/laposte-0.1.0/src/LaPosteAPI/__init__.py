from LaPosteAPI.LaPoste import LaPoste, Suivi
import LaPosteAPI.LaPosteExeptions